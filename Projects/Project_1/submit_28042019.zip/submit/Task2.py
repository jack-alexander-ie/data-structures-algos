"""
Read file into texts and calls.
It's ok if you don't understand how to read files
"""
import csv

with open('texts.csv', 'r') as f:
    reader = csv.reader(f)
    texts = list(reader)

with open('calls.csv', 'r') as f:
    reader = csv.reader(f)
    calls = list(reader)

"""
TASK 2: Which telephone number spent the longest time on the phone
during the period? Don't forget that time spent answering a call is
also time spent on the phone.
Print a message:
"<telephone number> spent the longest time, <total time> seconds, on the phone during 
September 2016.".
"""

longest_record = []
longest_time = 0

for call in calls:

    incoming_number, time_spent = call.pop(0), int(call.pop())

    if time_spent > longest_time:

        longest_time = time_spent
        longest_record = incoming_number, time_spent

longest_record_str = "{calling} spent the longest time, {duration} seconds, on the phone during September 2016."
print(longest_record_str.format(calling=longest_record[0], duration=longest_record[1]))
